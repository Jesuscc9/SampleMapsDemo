# Xamarin-Forms-Maps-Sample
Provides a sample code using Xamarin.Forms.Maps.

Displays ordinary pins Pins on Maps:

<img src="https://github.com/HoussemDellai/Xamarin-Forms-Maps-Sample/blob/master/items/maps.png?raw=true" width="70%"/>

Displays custom pins Pins on Maps:

<img src="https://github.com/HoussemDellai/Xamarin-Forms-Maps-Sample/blob/master/items/maps2.png?raw=true"  width="70%"/>
