using Xamarin.Forms.Maps;

namespace MapsApp
{
    public class CustomPin
    {
        public Pin Pin { get; set; }
        public string Url { get; set; }
    }
}